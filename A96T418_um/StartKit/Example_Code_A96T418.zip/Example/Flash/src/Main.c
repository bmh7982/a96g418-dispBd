/**
 *******************************************************************************
 * @file        Main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "intrins.h"
#include "delay.h"
#include "A96T418_flash.h"
#include "A96T418_gpio.h"
#include "A96T418_clock.h"

/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
uint8_t write_data[PAGE_BUFFER_SIZE];
uint8_t read_data[PAGE_BUFFER_SIZE];

/* Private Function Prototype ------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void main(void)
{
	uint8_t i;
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);   
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);        // 0.5sec
	
	Port_SetOutputHighpin(PORT2, PIN0);  
    
    /* Enable INT */
	GLOBAL_INTERRUPT_EN();
	
	Init_Flash();

	/* Flash erese/write */
	for(i = 0; i < PAGE_BUFFER_SIZE ; i++)
	{
		write_data[i] = i;
	}
	Update_Flash_Buf(write_data, PAGE_BUFFER_SIZE);
	
	//Flash Write
	Update_Flash(FLASH_KEY);
	
	Read_Flash(FLASH_ADDR_USER, PAGE_BUFFER_SIZE, read_data);
	
	/* Flash erese/write */
	NOP; // check flash
	
  /* Infinite loop */
	while(1)
	{
		NOP;
		// End Flash erase/wrtie
		Port_SetOutputLowpin(PORT2, PIN0);
	}
}

/* --------------------------------- End Of File ------------------------------ */