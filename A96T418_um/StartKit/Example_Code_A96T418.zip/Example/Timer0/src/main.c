/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_timer0.h"
/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/

/* Public Variable -----------------------------------------------------------*/
/* Public Function -----------------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
int Main(void)
{
	unsigned char i=0;

	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);   
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);        // 0.5sec
	
    /* Timer0 initialize @0.5MHz*/
	Timer0_Initial(T0_PWM_MODE, TIMER_DIV32);
	
	/* Set PMW output (Alternative function) */
	Port_SetAlterFunctionpin(PORT2, PIN7, 0x2); //T0O/PWM0O
	
	/* Enable Timer0 overflow interrupt */
	Timer0_ConfigureInterrupt(OVERFLOW_INT, TRUE);
	Timer0_ConfigureInterrupt(MATCH_INT, TRUE);

	/* Timer0 Start */
	Timer0_Start();
	
    /* Enable INT */
	GLOBAL_INTERRUPT_EN();   

    /* Infinite loop */
	while(1)
	{
			if(i >= 0xFF)
				i = 0;
			
			Timer0_SetPWM(i++);
			NOP_10us_Delay(5000);        // 50msec
	}
}

/**********************************************************************
 * @brief		Timer0 match interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void TIMER0_MAT_Int(void) interrupt T0_MATCH_VECT
{
	Port_SetOutputTogglepin(PORT2, PIN1);
	NOP;
}

/**********************************************************************
 * @brief		Timer0 overflow interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void TIMER0_OVER_Int(void) interrupt T0_OVER_VECT
{
	Port_SetOutputTogglepin(PORT2, PIN0);
}

/* --------------------------------- End Of File ------------------------------ */