/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_timer3.h"

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main(void)
{
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);
    /* System Stabilize Delay */
    NOP_10us_Delay(50000);         // 0.5sec

    /* Timer3 initialize @ 16MHz */
	Timer3_Initial(T3_COUNTER_MODE, TIMER3_DIV1);
	
		/* Timer3 Match counter count(16000) / 16MHz = 1ms */
	Timer3_SetMatchCounter(16000);
	
    /* Enable timer3 match INT */   
 Timer3_ConfigureInterrupt(TRUE);

		/* Timer3 start */
	Timer3_Start();	
	
    /* Enable INT */
	GLOBAL_INTERRUPT_EN(); 
	
    /* Infinite loop */    
	while(1)
	{

	}
}

void TIMER3_Int(void) interrupt T3_MATCH_VECT
{
	Port_SetOutputTogglepin(PORT2, PIN0);
}

/* --------------------------------- End Of File ------------------------------ */