/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_timer5.h"

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main(void)
{
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);
    /* System Stabilize Delay */
    NOP_10us_Delay(50000);         // 0.5sec
	
		/* Timer5 initialize @ TIMER5_DIV8 */
	Timer5_Initial(T5_COUNTER_MODE, TIMER5_DIV8);
	
	 /* Timer5 Match Counter (2000) 2MHz/2000 = 1kHz  */
	Timer5_SetMatchCounter(2000);
	
		/* Enable timer5 match INT */   
 Timer5_ConfigureInterrupt(TRUE);
	
	/* Timer5 start */
	Timer5_Start();	
	
    /* Enable INT */
	GLOBAL_INTERRUPT_EN(); 
	
    /* Infinite loop */    
	while(1)
	{
		//NOP;
	}
}

/**********************************************************************
 * @brief		Timer5,5 interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void TIMER45_Int(void) interrupt T45_MATCH_VECT
{
	//P12 ^= 0x1; //speed optimize
	Port_SetOutputTogglepin(PORT2, PIN0);
	Timer5_ClearInterruptFlag();
}

/* --------------------------------- End Of File ------------------------------ */
