/**
 *******************************************************************************
 * @file        Main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_usart1_uart.h"

void putstring(char *str)
{
	while(*str != 0)
		USART1_SendDataWithInterrupt(*str++);
}

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main( void )
{
	uint8_t tempw=0, tempr=0;
	GLOBAL_INTERRUPT_DIS();     // disable INT. during peripheral setting
  /* Port initialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);         
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);         // 0.5sec
	
	/*Set Alernative Function for USART P16(RXD1) / P17(TXD1)*/
	Port_SetInputpin(PORT1, PIN6, TRUE); //input pullup enable
	Port_SetAlterFunctionpin(PORT1, PIN6, 0x3);
	Port_SetAlterFunctionpin(PORT1, PIN7, 0x3);
	
	USART1_Initial(9600, USART1_DATA_8BIT, USART1_STOP_1BIT, USART1_PARITY_NO, USART1_TX_RX_MODE);
	
	USART1_ConfigureInterrupt(USART1_RX_COMPLETE_INT, TRUE);
	USART1_ConfigureInterrupt(USART1_TX_COMPLETE_INT, TRUE);
	
	GLOBAL_INTERRUPT_EN();

	putstring("A96T418 USART1 INTERRUPT TEST!!\n\r");
	
	NOP_10us_Delay(50000);         // 0.5sec	

	while (1)
	{
		tempr = USART1_ReceiveDataWithInterrupt();
		tempw=tempr;
		USART1_SendDataWithInterrupt(tempw);  
	}
}

/* --------------------------------- End Of File ------------------------------ */
