/**
 *******************************************************************************
 * @file        Main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_usart1_spi.h"

uint8_t xdata write_data[4] _at_ 0x0300;
uint8_t xdata read_data[4] _at_ 0x0320;

uint8_t num = 0, tempr;

void Main( void )
{
	volatile uint8_t i;
    /* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();  
    /* Port initialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);           
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);         // 0.5sec
	
	/* Set Alternative function  MISO2(P16) / MOSI2(P17) */
	Port_SetAlterFunctionpin(PORT1, PIN6, 0x3);
	Port_SetAlterFunctionpin(PORT1, PIN7, 0x3);
	/* Set Alternative function  SCK2(P15) / SS2(P14) */
	Port_SetAlterFunctionpin(PORT1, PIN4, 0x3);
	Port_SetAlterFunctionpin(PORT1, PIN5, 0x3);
	
	USART1_SPI_Initial(SPI2_SLAVE_MODE, 0, SPI2_LSB, SPI2_CPOL_LOW, SPI2_CPHA_1EDGE, SPI2_TX_RX_MODE, SPI2_SS_HW_ENABLE);
	//0x05 ack data
	while(!(USTAT & (UDRE)));
	UDATA = 0x05;
	i=UDATA; //buffer emptying for avoiding overrun	//RXC auto clear 
	i=UDATA; //buffer emptying for avoiding overrun	//RXC auto clear 

    /* Enable INT */
	GLOBAL_INTERRUPT_EN();    

	NOP_10us_Delay(100);    // 1msec delay
	
	while (1)
	{
		NOP;
		
		//USER CODE
		
		/* slave handling (Polling) */
		
		while(( USTAT & RXC)!= RXC);		// Wait Data in
		
		if (USTAT & DOR )
		{
			//DATA OVERUN handling(user)
			NOP;
		}
		tempr = UDATA;		
		if(tempr == 0xFF)
		{
			NOP;
		}
		else
		{
			read_data[num++%4] = tempr;
		}
		while(!(USTAT & (UDRE)));
		//0x05 ack data
		UDATA = 0x05;
		
	}
}

/* --------------------------------- End Of File ------------------------------ */