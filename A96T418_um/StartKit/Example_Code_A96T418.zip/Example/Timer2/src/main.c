/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_timer2.h"

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main(void)
{
	uint16_t  i= 0;
	
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);
    /* System Stabilize Delay */
    NOP_10us_Delay(50000);         // 0.5sec

		/* Timer2 PPG port (Alternative function) */
	Port_SetAlterFunctionpin(PORT1, PIN2, 0x3);
	
    /* Timer2 initialize @ 2MHz */
	Timer2_Initial(T2_PPG_REPEAT_MODE, TIMER2_DIV8);
	
	 /* Timer2 PPG Polarity Start Low */
	Timer2_SetPPGPolarity(T2_START_LOW);
	
	 /* Timer2 PPG Period Counter (20000) 2M/20000 = 100Hz  */
	Timer2_SetPPGPeriodCounter(20000);
	
    /* Enable timer2 match INT */   
 Timer2_ConfigureInterrupt(TRUE);

		/* Timer2 start */
	Timer2_Start();	
	
    /* Enable INT */
	GLOBAL_INTERRUPT_EN(); 
	
    /* Infinite loop */    
	while(1)
	{
			if(i >= 20000)
				i = 0;
			
			Timer2_SetPPGDutyCounter(i++);
			NOP_10us_Delay(100);        // 1msec
	}
}

void TIMER2_Int(void) interrupt T2_MATCH_VECT
{
	Port_SetOutputTogglepin(PORT2, PIN0);
}

/* --------------------------------- End Of File ------------------------------ */