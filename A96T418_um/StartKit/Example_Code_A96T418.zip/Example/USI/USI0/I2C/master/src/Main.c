/**
 *******************************************************************************
 * @file        Main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_usi_i2c.h"
/* Private Pre-processor Definition & Macro ----------------------------------*/

/* Private Typedef -----------------------------------------------------------*/

/* Private Variable ----------------------------------------------------------*/
uint8_t xdata write_data[I2C_MAX_BUFFER_SIZE] _at_ 0x0300;
uint8_t xdata read_data[I2C_MAX_BUFFER_SIZE] _at_ 0x0320;


/* Private Function Prototype ------------------------------------------------*/

//------------------------------------------------------------------------------
//	Project include function code
//------------------------------------------------------------------------------

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main( void )
{
	uint8_t i;
    /* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port initialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);         
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);         // 0.5sec
	
	/* Set Alternative function  SCL0(P10) / SDA0(P11) */
	Port_SetAlterFunctionpin(PORT1, PIN0, 0x3);
	Port_SetAlterFunctionpin(PORT1, PIN1, 0x3);
	
	 /* Initialize USI0 I2C master mode*/
	USI_I2C_Initial(I2C_CH0, I2C_SPEED, 0x00, I2C_ACK_ENABLE);

    /* Enable INT */
	GLOBAL_INTERRUPT_EN();
	

	for(i = 0; i < 8; i++)
	{
		write_data[i] = 0x11*(1+i);   //Data
	}


	NOP_10us_Delay(50000);    // 0.5sec delay

	 /* Enable USI0 I2C interrupt */
	USI_I2C_ConfigureInterrupt(I2C_CH0, TRUE);
	
    /* Infinite loop */
	while(1)
	{          
		USI_I2C_MasterTransferData(I2C_CH0, I2C_DEVICE_ADDRESS, write_data, 8, read_data, 8);
			
		NOP_10us_Delay(100000);    // 1sec delay
		NOP_10us_Delay(100000);    // 1sec delay
		NOP_10us_Delay(100000);    // 1sec delay
		
	}


}

/* --------------------------------- End Of File ------------------------------ */
