/**
 *******************************************************************************
 * @file        Main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_usi_usart.h"

volatile uint8_t temptx=0, temprx=0;

void putstring(char *str)
{
	while(*str != 0)
		USI_USART_SendDataWithPolling(USART_CH0, str++, 1);
}

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main( void )
{
	GLOBAL_INTERRUPT_DIS();     // disable INT. during peripheral setting
  /* Port initialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);         
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);         // 0.5sec
	
	/*Set Alernative Function for USART P10(RXD0) / P11(TXD0)*/
	Port_SetInputpin(PORT1, PIN0, TRUE); //input pullup enable
	Port_SetAlterFunctionpin(PORT1, PIN0, 0x3);
	Port_SetAlterFunctionpin(PORT1, PIN1, 0x3);
	
	USI_USART_Initial(USART_CH0, 9600, USART_DATA_8BIT, USART_STOP_1BIT, USART_PARITY_NO, USART_TX_RX_MODE);
	
	GLOBAL_INTERRUPT_EN();

	putstring("A96T418 USI_UART POLLING TEST!!\n");
	
	NOP_10us_Delay(50000);         // 0.5sec	

	while (1)
	{
		USI_USART_ReceiveDataWithPolling(USART_CH0, &temprx, 1);
		temptx=temprx;
		USI_USART_SendDataWithPolling(USART_CH0, &temptx, 1);  
	}
}

/* --------------------------------- End Of File ------------------------------ */