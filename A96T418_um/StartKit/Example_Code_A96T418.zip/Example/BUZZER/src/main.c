/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/		
#include "A96T418.h"
#include "delay.h"
#include "Intrins.h"
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_buzzer.h"

/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/

/* Public Variable -----------------------------------------------------------*/
/* Public Function -----------------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main(void)
{
    /* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);

    /* Enable INT */
	GLOBAL_INTERRUPT_EN();   

	NOP_10us_Delay(100);        // 1msec delay

	/*Set Alernative Function for Buzzer Port P03*/
	Port_SetAlterFunctionpin(PORT0, PIN3, 0x1);
	
	/* Buzzer initialize @ sys 16MHz*/
	Buzzer_Initial(16000000, 0, BUZZER_DIV32);

	/* Infinite loop */
	while(1)
	{
			/* Buzzer Start @ Buzzer Freq = 250kHz*/
			Buzzer_Start();
			NOP_10us_Delay(10000);        // 100msec delay
			/* Buzzer Stop@ Buzzer Freq = 250kHz*/
			Buzzer_Stop();
			NOP_10us_Delay(10000);        // 100msec delay
	}
}

/* --------------------------------- End Of File ------------------------------ */
