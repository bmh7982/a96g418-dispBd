/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "a96T418_gpio.h"
#include "a96T418_clock.h"
/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/

/* Public Variable -----------------------------------------------------------*/
/* Public Function -----------------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main()
{
    unsigned char i = 0, j=0;
    /* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock 16Mhz initialize */
	Clock_Initial(HSI16_DIV1);     
    
    /* Enable INT */
	GLOBAL_INTERRUPT_EN();    
	
	for(i=0;i<2;i++)
	{
		Port_SetOutputHighpin(PORT2, (PIN0 + i));
		Port_SetOutputpin(PORT2, (PIN0 + i), PUSH_PULL);
	}

   /* Infinite loop */
	while(1)
	{
        for(i=0;i<2;i++)
        {
			Port_SetOutputLowpin(PORT2, (PIN0 + i));
			for(j=0;j<2;j++)
				NOP_10us_Delay(10000);
        }
		for(j=0;j<3;j++)
			NOP_10us_Delay(10000);
								
        for(i=0;i<2;i++)
        {
			Port_SetOutputHighpin(PORT2, (PIN0 + (1-i)));
			for(j=0;j<2;j++)
				NOP_10us_Delay(10000);
        }		
		for(j=0;j<3;j++)
			NOP_10us_Delay(10000);
								
		for(i=0;i<2;i++)
			 Port_SetOutputLowpin(PORT2, (PIN0 + i));
  
		for(i=0;i<10;i++)
			NOP_10us_Delay(10000);

		for(i=0;i<2;i++)
			 Port_SetOutputHighpin(PORT2, (PIN0 + i));
				
		for(i=0;i<10;i++)
			NOP_10us_Delay(10000);

	}
	
}

/* --------------------------------- End Of File ------------------------------ */
