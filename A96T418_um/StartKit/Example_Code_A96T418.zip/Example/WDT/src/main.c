/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "delay.h"
#include "a96T418_wdt.h"
#include "a96T418_gpio.h"
#include "a96T418_clock.h"
#include "a96T418_bit.h"

/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void main(void)
{
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);   
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);        // 0.5sec
	
	Port_SetOutputHighpin(PORT2, PIN0);
	Port_SetOutputHighpin(PORT2, PIN1);
	
    /* WDT initialize */
	BIT_Initial(BIT_LSI_DIV32, BIT_X256); //BIT period=64ms 
	//WDT_Initial(WDT_RST_ON, WDT_BIT_OVER);	//WDT clock source=64ms 
	WDT_Initial(WDT_FREE_RUN, WDT_BIT_OVER);	//WDT clock source=64ms 
	WDT_SetDATA(7); //WDT period=512ms
        
	//WDT_Set_500msec_Reset();

	/* Enable WDT INT */
	WDT_ConfigureInterrrupt(WDT_INT_EN);
    
	WDT_Start();

    /* Enable INT */
	GLOBAL_INTERRUPT_EN();
    
    /* Infinite loop */
	while(1)
	{
		if(RSTFR & (0x20))  // WDT reset flag check
		{
			if(BIT_GetInterruptStatus()) { 
				BIT_ClearInterruptStatus();
				Port_SetOutputTogglepin(PORT2, PIN0);
			}
		}
	}
}

/**********************************************************************
 * @brief		Watch Dog Timer overflow interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void WDT_OVER_Int(void) interrupt WDT_VECT
{
	Port_SetOutputTogglepin(PORT2, PIN1);
}

/* --------------------------------- End Of File ------------------------------ */
