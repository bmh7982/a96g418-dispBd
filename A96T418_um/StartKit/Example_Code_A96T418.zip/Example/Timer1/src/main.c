/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_timer1.h"
/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/

/* Public Variable -----------------------------------------------------------*/
uint32_t capture_cnt;
uint16_t capture_msec;
uint8_t button_flag;
#define	CAPTUREBUFSIZE	10
uint32_t captureBuf[CAPTUREBUFSIZE] _at_ 0x0000;
uint32_t captureBufIndx=0;

/* Public Function -----------------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main(void)
{
	uint16_t  i= 0;
	
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize @ 16MHz*/
	Clock_Initial(HSI16_DIV1);
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);	        // 0.5sec

		/* Timer1 Capture port (input) */
	Port_SetInputpin(PORT2, PIN5, PULL_UP);
	
	/* Enable EXT11 INT */  
	Port_ConfigureInterrupt(EXTINT_CH11, FALLING_EDGE);
	Port_EnableInterrupt(EXTINT_CH11);

    /* Timer1 initialize @ 16MHz */
	Timer1_Initial(T1_CAPTURE_MODE, TIMER1_DIV1);	//1/16us*0xFFFF=4096us
	/* Enable timer1 INT */   
	Timer1_ConfigureInterrupt(TRUE);
	/* Timer1 start */
	Timer1_Start();	
	
    /* Enable INT */
	GLOBAL_INTERRUPT_EN(); 
    
	capture_cnt = 0;
	button_flag = 0;
	
	BITCR&=~0x80; //BIT Flag clear
	
    /* Infinite loop */
	while(1)
	{
		if(BITCR&0x80) { 
			BITCR&=~0x80;
			Port_SetOutputLowpin(PORT1, PIN3); //connect P13 to P25 for capture
			NOP; 					
			Port_SetOutputHighpin(PORT1, PIN3); //P13 period=16ms 
		}
		
		if(button_flag >= 2)
		{
			//16MHz count / 16000 => 16ms
			capture_msec = capture_cnt / (16000);
			NOP; //for debug
		}
		//NOP_10us_Delay(100);        // 1msec
	}
}

/**********************************************************************
 * @brief		Timer1 interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void TIMER1_Int(void) interrupt T1_MATCH_VECT
{
	Port_SetOutputTogglepin(PORT2, PIN1);
	if(button_flag==1)
	{
		//add overflow value
		capture_cnt += 0x10000; 
	}	
}


/**********************************************************************
 * @brief		EXT11 interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void EXTINT11_Int(void) interrupt EINT11_VECT
{
		//test pin toggle
		Port_SetOutputTogglepin(PORT2, PIN0);
	
		if(!button_flag)
		{	
			capture_cnt = 0;
			button_flag = 1;		
		}
		else if(button_flag==1)
		{
			capture_cnt += Timer1_GetCaptureValue();
			if(captureBufIndx<CAPTUREBUFSIZE) {
				captureBuf[captureBufIndx++]=capture_cnt;
				if(captureBufIndx>=CAPTUREBUFSIZE) {
					/* Disable EXT11 INT */  
					Port_ConfigureInterrupt(EXTINT_CH11, NONE);				
					Port_DisableInterrupt(EXTINT_CH11);
					
					/* Disable timer1 INT */   
					//Timer1_ConfigureInterrupt(FALSE);
					/* Timer1 stop */
					//Timer1_Stop();	
					button_flag=2;
					_nop_();
				}
				else
					capture_cnt=0;
			}
		}			
		//clear interrupt flag
		Port_ClearInterruptStatus(EXTINT_CH11);

}


/* --------------------------------- End Of File ------------------------------ */