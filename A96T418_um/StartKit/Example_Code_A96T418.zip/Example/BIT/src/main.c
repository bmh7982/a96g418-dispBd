/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
//#include    "Global.h"      //
//#include    "Sysfunc.h"     //
#include    "delay.h"     //
#include "a96T418_gpio.h"
#include "a96T418_clock.h"
#include "a96T418_bit.h"

/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/
/* Public Variable -----------------------------------------------------------*/
/* Public Function -----------------------------------------------------------*/

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main(void)
{
	unsigned char i=0;

    /* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port initialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);
    
    /* BIT initialize (period 64ms)*/   
	BIT_Initial(BIT_LSI_DIV32, BIT_X256);
 	//BIT_Initial(BIT_TEMPSENSOR, BIT_X2);
   
    /* Enable BIT INT */
  BIT_Interrupt_config(TRUE);
    
    /* Enable INT */
	GLOBAL_INTERRUPT_EN(); 
  NOP_10us_Delay(10);
    /* Infinite loop */
	while(1)
	{
			NOP;
	}
}

/**
 * @brief		BIT interrupt subroutine
 * @param   	None
 * @return	    None
*/
void BIT_Int_Handler(void) interrupt BIT_VECT
{
    Port_SetOutputTogglepin(PORT2, PIN0);			//BIT Int 64ms toggle!
    Port_SetOutputTogglepin(PORT2, PIN1);			//BIT Int 64ms toggle!
}

/* --------------------------------- End Of File ------------------------------ */

