/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include    "Intrins.h"
#include    "delay.h"     //
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_adc.h"

/* Private Variable ----------------------------------------------------------*/
uint16_t avg_data = 0;
uint16_t temp_data[ADC_MAX_BUFFER_SIZE];

/**********************************************************************
 * @brief		Main program
 * @param   	None
 * @return	    None
 **********************************************************************/
void Main( void )
{
	uint8_t i;
	
    /* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port initialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV2);         
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);         // 0.5sec
	
	/* Set Alternative function  AN0(P04) */
	Port_SetAlterFunctionpin(PORT0, PIN4, 0x2);
	Port_SetInputpin(PORT0, PIN4, NO_PULL);
	
	 /* Initialize ADC */
	ADC_Initial(ADC_CLK_DIV2, ADC_SW_TRIG, ADC_INTERNAL_REF, ADC_LSB);
	
		/* Selection ADC input channel */
	ADC_SelectChannel(ADC_CH0);
	
    /* Enable INT */
	GLOBAL_INTERRUPT_EN();
	
	NOP_10us_Delay(50000);    // 0.5sec delay

    /* Infinite loop */
	while(1)
	{          
		avg_data = 0;
	
		ADC_GetDataWithInterrupt(temp_data, ADC_MAX_BUFFER_SIZE);
		for(i = 0; i < ADC_MAX_BUFFER_SIZE; i++)
		{
			avg_data += temp_data[i];
		}
		Port_SetOutputTogglepin(PORT2, PIN0);
		
		avg_data /= 16;
		
		NOP; //for debug
		
		NOP_10us_Delay(50000);    // 0.5sec delay
		NOP_10us_Delay(50000);    // 0.5sec delay

	}


}

/* --------------------------------- End Of File ------------------------------ */

