/**
 *******************************************************************************
 * @file        main.c
 * @author      ABOV R&D Division
 * @brief       Main Example Code
 *
 * Copyright 2020 ABOV Semiconductor Co.,Ltd. All rights reserved.
 *
 * This file is licensed under terms that are found in the LICENSE file
 * located at Document directory.
 * If this file is delivered or shared without applicable license terms,
 * the terms of the BSD-3-Clause license shall be applied.
 * Reference: https://opensource.org/licenses/BSD-3-Clause
 ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "delay.h"
#include "A96T418_gpio.h"
#include "A96T418_clock.h"
#include "A96T418_WT.h"
#include "intrins.h"
/* Private Pre-processor Definition & Macro ----------------------------------*/
/* Private Typedef -----------------------------------------------------------*/
/* Private Variable ----------------------------------------------------------*/
/* Private Function Prototype ------------------------------------------------*/

void main(void)
{
	/* Disable INT. during peripheral setting */
	GLOBAL_INTERRUPT_DIS();     
    
    /* Port intialize */
	Port_Initial();		        
    /* Clock initialize */
	Clock_Initial(HSI16_DIV1);   
    /* System Stabilize Delay */
	NOP_10us_Delay(50000);                      // 0.5sec    
  
    /* WT initialize 16Mhz -> 65.536ms*/
	WT_Initial(FWCK_DIV16384_WTDR1, FX_DIV64);
 
	
	//WT_SetDataValue(15);  //1s
	WT_SetDataValue(7);  //524ms
	
    /* Enable WT INT */
	WT_ConfigureInterrrupt(WT_INT_EN);

   	/* Watch Timer Start */ 
	WT_Start();
    
    /* Enable INT */
	GLOBAL_INTERRUPT_EN();  
    
    /* Infinite loop */
	while(1)
	{
		NOP;
		NOP_10us_Delay(5000);        // 50msec
	}
}

/**********************************************************************
 * @brief		WT interrupt subroutine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
void WT_Int_Handler() interrupt WT_VECT
{
    Port_SetOutputTogglepin(PORT2, PIN0);
}

/* --------------------------------- End Of File ------------------------------ */